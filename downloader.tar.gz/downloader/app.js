var request = require("request");
var fs = require('fs');
var mkdirp = require('mkdirp');

var domain = 'www.wired.com';
var webSite = encodeURIComponent('http://' + domain + '/');
var indexRequest = 'http://index.commoncrawl.org/CC-MAIN-2015-18-index?url=' + webSite + '*&output=json';
var s3Url = 'https://aws-publicdatasets.s3.amazonaws.com/';
var outputFile = 'output/' + domain + '/news';
var extension = '.warc.gz';

mkdirp('output/' + domain + '/', function(err) { 
    if (err) throw err;
    console.log('Retrieving domain ' + domain);
});

request(indexRequest, function(err, response, body) {

	var warcsPos = body.split("\n");
	console.log("Retrieved " + (warcsPos.length - 1) + " warc files");

	warcsPos.forEach(function(warcPos, i) {

		if (warcPos) {
			var json = JSON.parse(warcPos);

			var url = s3Url + json['filename'];
			var start = parseInt(json['offset']);
			var end = start + parseInt(json['length']) - 1;

			var headers = { 'Range' :  'bytes=' + start + '-' + end };
			var options = { 'url' : url, 'headers' : headers, 'encoding' : null};

			request(options, function(err, response, body) {
				fs.writeFile(outputFile + i + extension, body, function (err) {
					if (err) throw err;
				});
			});
		}

	});

});