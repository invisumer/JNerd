package it.uniroma3.ner.util;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import de.l3s.boilerpipe.BoilerpipeProcessingException;
import de.l3s.boilerpipe.extractors.ArticleExtractor;

public class HtmlBuilder {

	public static Map<String, String> build(String url, String httpResponse, byte[] htmlStream) {
		Map<String, String> output = new HashMap<String, String>();
		
		try {
			String html = new String(htmlStream, getEnc());
			Document htmlDoc = Jsoup.parse(html);
			
			htmlDoc.select("footer").remove();
			
			String body = htmlDoc.body().toString();
			if (body == null)
				return null;

			body = ArticleExtractor.INSTANCE.getText(body);
			
			String lang = getLang();
			
			if (body != null)
				output.put("body", body);
			if (url != null)
				output.put("url", url);
			if (lang != null)
				output.put("lang", lang);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (BoilerpipeProcessingException e) {
			e.printStackTrace();
		}

		return output;
	}
	
	// eventually encoding detection and language detection algorithms here
	
	private static String getEnc() {
		return "utf-8";
	}
	
	private static String getLang() {
		return "en";
	}

}