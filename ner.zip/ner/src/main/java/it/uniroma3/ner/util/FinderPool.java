package it.uniroma3.ner.util;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import opennlp.tools.namefind.NameFinderME;
import opennlp.tools.namefind.TokenNameFinderModel;

public class FinderPool {
	
	private static final NerdManager manager = NerdManager.getInstance();
	private BlockingQueue<Map<String, NameFinderME[]>> pool;
	private int poolSize;
	
	public FinderPool(int N) {
		poolSize = N;
		pool = new ArrayBlockingQueue<Map<String, NameFinderME[]>>(N);
		setup();
	}
	
	private void setup() {
		List<String> languages = manager.LANGUAGES;
		List<String> types = manager.ENTITY_TYPES;
		
		for (int p=0; p < poolSize; p++) {
				
			try {
				Map<String, NameFinderME[]> lang2finder = new HashMap<String, NameFinderME[]>();
				
				for (String lang : languages) {
					NameFinderME[] finder = new NameFinderME[types.size()];
					for (int i=0; i<finder.length; i++) {
						String pathname = manager.TRAINING_SET_PATH +
								"/" + lang + "-ner-" + types.get(i) + ".bin";
						TokenNameFinderModel model = new TokenNameFinderModel(new File(pathname));
						finder[i] = new NameFinderME(model);
					}
					lang2finder.put(lang, finder);
				}
				
				pool.put(lang2finder);
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
		
	}
	
	public Map<String, NameFinderME[]> acquireFinder() throws InterruptedException {
		return pool.take();
	}
	
	public void releaseFinder(Map<String, NameFinderME[]> finder) throws InterruptedException {
		pool.put(finder);
	}

}
