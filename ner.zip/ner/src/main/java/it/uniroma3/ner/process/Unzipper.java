package it.uniroma3.ner.process;

import it.uniroma3.ner.util.WarcParser;

import java.io.InputStream;
import java.util.Map;
import java.util.zip.GZIPInputStream;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;

public class Unzipper implements Processor {
	
	@Override
	public void process(Exchange ex) throws Exception {
		Message m = ex.getIn();
		
		InputStream stream = m.getBody(InputStream.class);
		m.setBody(WarcParser.parse(new GZIPInputStream(stream)), Map.class);
		stream.close();
	}
	
}
