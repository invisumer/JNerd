package it.uniroma3.ner.process;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Body;
import org.apache.camel.Message;
import org.apache.camel.impl.DefaultMessage;

import edu.stanford.nlp.ie.AbstractSequenceClassifier;
import edu.stanford.nlp.ie.crf.CRFClassifier;
import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.ling.CoreAnnotations.AnswerAnnotation;
import it.uniroma3.ner.model.Entity;
import it.uniroma3.ner.model.PageEntities;
import it.uniroma3.ner.util.NerdManager;

public class StanfordEntityRecognizer implements EntityRecognizer {
	private static final NerdManager manager = NerdManager.getInstance();
	String serializedClassifier = manager.TRAINING_SET_PATH+"/english.all.3class.distsim.crf.ser.gz";
	AbstractSequenceClassifier<CoreLabel> classifier;
	
	public StanfordEntityRecognizer() {
		try {
			classifier = CRFClassifier.getClassifier(serializedClassifier);
		} catch (ClassCastException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public List<Message> split(@Body Map<String, String> body) {
		List<Message> outs = new ArrayList<Message>(2);
		Map<String, StringBuilder> results = tag(body);
		
		if (results.get("result") != null && results.get("result").length() > 0)
			outs.add(createMessage(results.get("result"), manager.INDEX_DESTINATION));
		if (results.get("resultMapReduce") != null && results.get("result").length() > 0)
			outs.add(createMessage(results.get("resultMapReduce"), manager.MAPREDUCE_DESTINATION));
		
		return outs;
	}
	
	private Message createMessage(StringBuilder result, String destination) {
		Message out = new DefaultMessage();
		
		out.setHeader(manager.DESTINATION_HEADER, destination);
		out.setBody(result, StringBuilder.class);
		
		return out;
	}
	
	private Map<String, StringBuilder> tag(Map<String, String> page) {
		String url = page.get("url");
		String body = page.get("body");
		body = body.trim();
		Map<String, StringBuilder> result = new HashMap<String, StringBuilder>();
		String currentEntity = "";
		String currentType = "";
		PageEntities currentPage = new PageEntities(url);
		List<List<CoreLabel>> entity = classifier.classify(body);
		for (List<CoreLabel> l : entity) {
    		for (CoreLabel co : l) {
    			String ans = co.get(AnswerAnnotation.class);
    			if (!ans.equals("O")) {
    				if (co.get(AnswerAnnotation.class).equals(currentType)) {
    					currentEntity = currentEntity+co.toString()+" ";
    				} else {
    					if (!currentEntity.equals("")) {
    						currentEntity = currentEntity.substring(0, currentEntity.length()-1);
	    					currentPage.addEntity(new Entity(currentType,currentEntity));
    					}
    					currentType = co.get(AnswerAnnotation.class);
    	    			currentEntity = co.toString()+" ";
    				}
    				
    			} else if (!currentEntity.equals("")) {
					currentEntity = currentEntity.substring(0, currentEntity.length()-1);
					currentPage.addEntity(new Entity(currentType,currentEntity));
					currentType = "";
					currentEntity = "";
				}
			}
    	}
		if (!currentEntity.equals("")) {
			currentEntity = currentEntity.substring(0, currentEntity.length()-1);
			currentPage.addEntity(new Entity(currentType,currentEntity));
		}
		result.put("result", currentPage.makeString());
		result.put("resultMapReduce", currentPage.makeStringMapReduce());
		return result;
	}
	
	
}
