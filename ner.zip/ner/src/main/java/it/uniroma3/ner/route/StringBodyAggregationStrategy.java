package it.uniroma3.ner.route;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;

public class StringBodyAggregationStrategy implements AggregationStrategy {

	@Override
	public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
 
		if(oldExchange == null) {
			String newMessage = newExchange.getIn().getBody(String.class);
			newExchange.getIn().setBody(new StringBuilder(newMessage));
			return newExchange;
		}
 
		StringBuilder oldBody = oldExchange.getIn().getBody(StringBuilder.class);
		String newBody = newExchange.getIn().getBody(String.class);
		oldBody.append(newBody);
 
		return oldExchange;
	}

}
