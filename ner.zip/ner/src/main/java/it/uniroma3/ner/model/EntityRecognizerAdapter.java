package it.uniroma3.ner.model;

import it.uniroma3.ner.process.EntityRecognizer;
import it.uniroma3.ner.process.OpenEntityRecognizer;
import it.uniroma3.ner.process.StanfordEntityRecognizer;

public class EntityRecognizerAdapter {
	
	public EntityRecognizerAdapter() {}
	
	public EntityRecognizer getRecognizer(String framework, int pool) {
		if (framework.equals("stanford"))
			return new StanfordEntityRecognizer();
		else if (framework.equals("open"))
			return new OpenEntityRecognizer(pool);
		else {
			return null;
		}
	}
}
