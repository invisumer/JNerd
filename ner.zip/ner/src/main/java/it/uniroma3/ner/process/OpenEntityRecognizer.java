package it.uniroma3.ner.process;

import it.uniroma3.ner.model.Annotation;
import it.uniroma3.ner.model.Entity;
import it.uniroma3.ner.model.PageEntities;
import it.uniroma3.ner.util.FinderPool;
import it.uniroma3.ner.util.NerdManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import opennlp.tools.namefind.NameFinderME;
import opennlp.tools.tokenize.SimpleTokenizer;
import opennlp.tools.tokenize.Tokenizer;
import opennlp.tools.util.Span;

import org.apache.camel.Body;
import org.apache.camel.Message;
import org.apache.camel.impl.DefaultMessage;

public class OpenEntityRecognizer implements EntityRecognizer {
	private static final NerdManager manager = NerdManager.getInstance();
	private FinderPool pool;
	
	public OpenEntityRecognizer(int N) {
		pool = new FinderPool(N);
	}

	public List<Message> split(@Body Map<String, String> body) {
		List<Message> outs = new ArrayList<Message>(2);
		Map<String, StringBuilder> results = tag(body);
		
		if (results.get("result") != null && results.get("result").length() > 0)
			outs.add(createMessage(results.get("result"), manager.INDEX_DESTINATION));
		if (results.get("resultMapReduce") != null && results.get("result").length() > 0)
			outs.add(createMessage(results.get("resultMapReduce"), manager.MAPREDUCE_DESTINATION));
		
		return outs;
	}
	
	private Message createMessage(StringBuilder result, String destination) {
		Message out = new DefaultMessage();
		
		out.setHeader(manager.DESTINATION_HEADER, destination);
		out.setBody(result, StringBuilder.class);
		
		return out;
	}
	
	private Map<String, StringBuilder> tag(Map<String, String> page) {
		String url = page.get("url");
		String body = page.get("body");
		String lang = page.get("lang");
		body = body.trim();
		Map<String, StringBuilder> result = new HashMap<String, StringBuilder>();
		List<Annotation> allAnnotations = new ArrayList<Annotation>();
		
		Tokenizer tokenizer = SimpleTokenizer.INSTANCE;
		String[] tokens = tokenizer.tokenize(body);
		
		try {
			Map<String,NameFinderME[]> lang2finder = this.pool.acquireFinder();
			
			NameFinderME[] finder = lang2finder.get(lang);
			if (finder == null)
				finder = lang2finder.get(manager.DEFAULT_LANGUAGE);
			
			for (int fi = 0; fi < finder.length; fi++) {
				Span[] spans = finder[fi].find(tokens);
				double[] probs = finder[fi].probs(spans);
				for (int ni = 0; ni < spans.length; ni++) {
					allAnnotations.add(new Annotation(
							manager.ENTITY_TYPES.get(fi), spans[ni], probs[ni]));
				}
			}
			
			this.pool.releaseFinder(lang2finder);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		removeConflicts(allAnnotations);
		StringBuilder build = getResult(url, allAnnotations, tokens);
		result.put("result", build);
		
		StringBuilder buildMapReduce = getResultMapReduce(allAnnotations, tokens);
		result.put("resultMapReduce", buildMapReduce);
		
		return result;
	}
	
	private void removeConflicts(List<Annotation> allAnnotations) {
		java.util.Collections.sort(allAnnotations);
		List<Annotation> stack = new ArrayList<Annotation>();
		if (!allAnnotations.isEmpty())
			stack.add(allAnnotations.get(0));
		for (int ai=1; ai<allAnnotations.size(); ai++) {
			Annotation curr = (Annotation) allAnnotations.get(ai);
			boolean deleteCurr = false;
			for (int ki = stack.size() - 1; ki >= 0; ki--) {
				Annotation prev = (Annotation) stack.get(ki);
				if (prev.getSpan().equals(curr.getSpan())) {
					if (prev.getProb() > curr.getProb()) {
						deleteCurr = true;
						break;
					} else {
						allAnnotations.remove(stack.remove(ki));
						ai--;
					}
				} else if (prev.getSpan().intersects(curr.getSpan())) {
					if (prev.getProb() > curr.getProb()) {
						deleteCurr = true;
						break;
					} else {
						allAnnotations.remove(stack.remove(ki));
						ai--;
					}
				} else if (prev.getSpan().contains(curr.getSpan())) {
					break;
				} else {
					stack.remove(ki);
				}
			}
			if (deleteCurr) {
				allAnnotations.remove(ai);
				ai--;
				deleteCurr = false;
			} else {
				stack.add(curr);
			}
		}
	}
	
	private StringBuilder getResult(String url, List<Annotation> allAnnotations, String[] tokens) {
		PageEntities page = new PageEntities(url);
		for (Annotation a : allAnnotations) {
			String entityValue = "";
			Entity entity = new Entity();
			entity.setType(a.getSpan().toString().split(" ")[1]);
			for (int i=a.getSpan().getStart(); i<a.getSpan().getEnd(); i++) {
				entityValue += tokens[i]+" ";
			}
			entityValue = entityValue.substring(0, entityValue.length()-1);
			entity.setName(entityValue);
			page.addEntity(entity);
		}
		return page.makeString();
	}
	
	private StringBuilder getResultMapReduce(List<Annotation> allAnnotations, String[] tokens) {
		PageEntities page = new PageEntities();
		for (Annotation a : allAnnotations) {
			String entityValue = "";
			Entity entity = new Entity();
			entity.setType(a.getSpan().toString().split(" ")[1]);
			for (int i=a.getSpan().getStart(); i<a.getSpan().getEnd(); i++) {
				entityValue += tokens[i]+" ";
			}
			entityValue = entityValue.substring(0, entityValue.length()-1);
			entity.setName(entityValue);
			page.addEntity(entity);
		}
		return page.makeStringMapReduce();
	}

}
