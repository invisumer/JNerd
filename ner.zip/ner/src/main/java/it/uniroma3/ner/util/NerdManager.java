package it.uniroma3.ner.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class NerdManager {
	private static NerdManager instance;
	private static final String propertyPath = "META-INF/config/ner.properties";
	
	private String ENTITIES;
	private String LANG;
	public List<String> ENTITY_TYPES = new ArrayList<String>();
	public List<String> LANGUAGES = new ArrayList<String>();
	public String TRAINING_SET_PATH, DEFAULT_LANGUAGE;
	public String DESTINATION_HEADER, INDEX_DESTINATION, MAPREDUCE_DESTINATION;
	
	private NerdManager() {
		try {
			
			Properties prop = new Properties();
			prop.load(this.getClass().getClassLoader().getResourceAsStream(propertyPath));
			
			//ENTITY TYPES
			ENTITIES = prop.getProperty("openNlp.entity.types");
			for (String entity : ENTITIES.split(",")) {
				ENTITY_TYPES.add(entity);
			}
			TRAINING_SET_PATH = prop.getProperty("trainingSet.path");
			DEFAULT_LANGUAGE = prop.getProperty("openNlp.entity.defaultLanguage");
			LANG = prop.getProperty("openNlp.entity.languages");
			for (String language : LANG.split(",")) {
				LANGUAGES.add(language);
			}
			
			DESTINATION_HEADER = prop.getProperty("camel.header.destination");
			INDEX_DESTINATION = prop.getProperty("camel.destination.index");
			MAPREDUCE_DESTINATION = prop.getProperty("camel.destination.mapreduce");
		
		} catch (FileNotFoundException e) {
			System.out.println("Properties file could not be found: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("Properties file could not be loaded: " + e.getMessage());
		}
	}
	
	public static synchronized NerdManager getInstance() {
		if (instance==null) 
			instance = new NerdManager();
		return instance;
	}
}
