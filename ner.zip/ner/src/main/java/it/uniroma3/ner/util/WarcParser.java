package it.uniroma3.ner.util;

import java.io.DataInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Map;
import java.util.zip.GZIPInputStream;

import edu.cmu.lemurproject.WarcHTMLResponseRecord;
import edu.cmu.lemurproject.WarcRecord;

public class WarcParser {

	public static Map<String, String> parse(GZIPInputStream stream) throws FileNotFoundException, IOException {
		DataInputStream dataStream = new DataInputStream(stream);
		Map<String, String> htmlParsed = null;
		WarcRecord record = null;

		if ((record = WarcRecord.readNextWarcRecord(dataStream)) != null) {
			if (record.getHeaderRecordType().equals("response")) {
				htmlParsed = parseRecord(record);
			}
		}
		
		return htmlParsed;
	}

	private static Map<String,String> parseRecord(WarcRecord record) {
		byte[] contentStream = record.getContent();

		// get url target
		String url = getUrlTarget(record);

		// get http response
		int httpLen = getHttpResponseLength(contentStream);
		String httpResponse = getHttpResponse(contentStream, httpLen);
		
		// get html page
		byte[] htmlStream = getBodyStream(contentStream, httpLen + 3);
		
		return HtmlBuilder.build(url, httpResponse, htmlStream);
	}

	private static String getUrlTarget(WarcRecord warc) {
		WarcHTMLResponseRecord htmlRecord = new WarcHTMLResponseRecord(warc);
		String url = htmlRecord.getTargetURI();
		return url;
	}

	private static int getHttpResponseLength(byte[] contentStream) {
		int i = 1;
		while (!((contentStream[i] == '\r') && (contentStream[i - 1] == '\n'))) {
			i++;
		}
		return i - 1;
	}

	private static String getHttpResponse(byte[] contentStream, int length) {
		byte[] httpResponseStream = new byte[length];

		for (int j = 0; j < length; j++)
			httpResponseStream[j] = contentStream[j];

		String httpResponse = null;

		try {
			httpResponse = new String(httpResponseStream, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		return httpResponse;
	}

	private static byte[] getBodyStream(byte[] contentStream, int start) {
		byte[] htmlStream = new byte[contentStream.length - start];
		for (int k = 0; k < htmlStream.length; k++)
			htmlStream[k] = contentStream[k + start];
		return htmlStream;
	}

}
