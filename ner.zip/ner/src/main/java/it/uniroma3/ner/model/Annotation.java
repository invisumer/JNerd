package it.uniroma3.ner.model;

import opennlp.tools.util.Span;

public class Annotation implements Comparable<Annotation>{
	String s;
	Span span;
	Double d;
	
	public Annotation(String s, Span span, double d) {
		this.s = s;
		this.span = span;
		this.d = d;
	}
	
	public Span getSpan() {
		return span;
	}
	
	public double getProb() {
		return d;
	}

	public int compareTo(Annotation o) {
		return (int) (this.span.compareTo(o.getSpan()));
	}
}