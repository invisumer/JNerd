package it.uniroma3.ner.process;

import java.util.List;
import java.util.Map;

import org.apache.camel.Body;
import org.apache.camel.Message;

public interface EntityRecognizer {
	public List<Message> split(@Body Map<String, String> body);
}
