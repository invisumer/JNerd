package it.uniroma3.ner.model;

import java.util.HashSet;
import java.util.Set;

public class PageEntities {
	String url;
	Set<Entity> e;
	int counter;
	
	public PageEntities(String url) {
		this.url = url;
		this.counter = 0;
		this.e = new HashSet<Entity>();
	}
	
	public PageEntities() {
		this.counter = 0;
		this.e = new HashSet<Entity>();
	}
	
	public void addEntity(Entity entity) {
		this.e.add(entity);
	}
	
	public StringBuilder makeString() {
		StringBuilder res = new StringBuilder(url);
		res.append("\t");
		for (Entity e : e) {
			res.append(e.toString()+"\t");
		}
		if (res.length()>0)
		res.deleteCharAt(res.length()-1);
		res.append("\n");
		return res;
	}
	
	public StringBuilder makeStringMapReduce() {
		StringBuilder res = new StringBuilder();
		for (Entity e : e) {
			res.append(e.toStringMapReduce()+",");
		}
		if (res.length()>0)
		res.deleteCharAt(res.length()-1);
		res.append("\n");
		return res;
	}
	
}
