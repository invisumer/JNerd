package it.uniroma3.ner;

import it.uniroma3.ner.model.EntityRecognizerAdapter;
import it.uniroma3.ner.process.EntityRecognizer;
import it.uniroma3.ner.process.Unzipper;
import it.uniroma3.ner.route.StringBodyAggregationStrategy;
import it.uniroma3.ner.util.NerdManager;

import java.io.File;
import java.util.Scanner;
import java.util.logging.Logger;

import org.apache.camel.CamelContext;
import org.apache.camel.LoggingLevel;
import org.apache.camel.ShutdownRunningTask;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.processor.idempotent.MemoryIdempotentRepository;

public class JNerd {
	
	private static final NerdManager manager = NerdManager.getInstance();
	private static final Logger logger = Logger.getLogger(JNerd.class.getName());

	public static void main(String[] args) {
		CamelContext context = setUpContext();

		try {
			final long shutdownTimeout = 3600;
			final int procs = Runtime.getRuntime().availableProcessors();
			final int recognizerPoolSize = procs;
			final int completionSize = 500;
			final long timeout = 2000;
			final int numFiles = new File("src/main/resources/META-INF/warc").listFiles().length;
			final MemoryIdempotentRepository repo = new MemoryIdempotentRepository();
			repo.setCacheSize(numFiles);

			System.out.println("Do you want to use Stanford NLP? Type <stanford>" + "\n" +
					"Do you want to use Apache OpenNLP Type <open>");
			Scanner input = new Scanner(System.in);
			final String frameworkToUse = input.nextLine();
			input.close();
			
			EntityRecognizerAdapter recognizerManager = new EntityRecognizerAdapter();
			final EntityRecognizer recognizer = recognizerManager.getRecognizer(frameworkToUse, recognizerPoolSize);
			if (recognizer==null) {
				System.out.println("Incorrect choice");
				System.exit(1);
			}
			
			context.addRoutes( new RouteBuilder() {
				@Override
				public void configure() throws Exception {

					from("file:src/main/resources/META-INF/warc?noop=true")
					.shutdownRunningTask(ShutdownRunningTask.CompleteAllTasks)
					.idempotentConsumer(header("CamelFileName"), repo)
					.to("seda:recognizer");

					from("seda:recognizer?concurrentConsumers=" + recognizerPoolSize)
					.shutdownRunningTask(ShutdownRunningTask.CompleteAllTasks)
					.doTry()
						.process(new Unzipper())
						.split()
						.method(recognizer, "split")
						.to("seda:aggregator")
					.endDoTry()
					.doCatch(Exception.class)
						.log(LoggingLevel.WARN,"Invalid GZip $simple{in.header.CamelFileName}")
					.end();

					from("seda:aggregator")
					.shutdownRunningTask(ShutdownRunningTask.CompleteAllTasks)
					.convertBodyTo(String.class)
					.aggregate(header(manager.DESTINATION_HEADER), new StringBodyAggregationStrategy())
					.completionSize(completionSize)
					.completionTimeout(timeout)
					.parallelProcessing()
					.to("seda:writer");
					
					from("seda:writer")
					.shutdownRunningTask(ShutdownRunningTask.CompleteAllTasks)
					.log("New batch ready to be written")
					.choice()
						.when(header(manager.DESTINATION_HEADER).isEqualTo(manager.INDEX_DESTINATION))
							.to("file:src/main/resources/META-INF/entities?fileName=index&fileExist=Append")
						.otherwise()
							.to("file:src/main/resources/META-INF/entities?fileName=mapReduce&fileExist=Append")
					.endChoice();
				}

			});
			
			long timeExpected = numFiles * 50 + 10000;

			context.getShutdownStrategy().setTimeout(shutdownTimeout);
			context.getShutdownStrategy().setSuppressLoggingOnTimeout(true);
			context.getShutdownStrategy().setLogInflightExchangesOnTimeout(false);
			System.out.println("Running time expected (s) : " + timeExpected / 1000);
			context.start();
			Thread.sleep(timeExpected);
			context.stop();
		} catch (Exception e) {
			e.printStackTrace();
			logger.severe("Could not start Camel context: " + e.getMessage());
		}
	}

	private static CamelContext setUpContext()  {
		CamelContext context = new DefaultCamelContext();
		return context;
	}
}
