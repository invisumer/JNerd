package it.uniroma3.ner.model;

public class Entity {
	
	private String type;
	private String name;
	private int occurrence;
	
	public Entity() {
		this.occurrence = 1;
	}
	
	public Entity(String type, String name) {
		this.occurrence = 1;
		this.name = name;
		this.type = type;
	}
	
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public int getOccurrence() {
		return this.occurrence;
	}
	
	public void addToOccurrence() {
		this.occurrence = this.occurrence+1;
	}
	
	@Override
	public String toString() {
		return type + ':' + name + '=' + occurrence;
	}
	
	public String toStringMapReduce() {
		return name;
	}
	
	public int hashCode() {
		return this.name.hashCode();
	}
	
	public boolean equals(Object o)	{
		boolean res = this.name.equals(((Entity) o).getName());
		if (res) 
			((Entity) o).addToOccurrence();
		return res;
	}

}