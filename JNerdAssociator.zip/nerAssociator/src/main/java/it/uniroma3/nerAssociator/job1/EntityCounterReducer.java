package it.uniroma3.nerAssociator.job1;

import it.uniroma3.nerAssociator.util.NerAssociatorManager;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class EntityCounterReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
	NerAssociatorManager manager = NerAssociatorManager.getInstance();
	int threshold = manager.JOB1_THRESHOLD;
	
	public void reduce(Text key, Iterable<IntWritable> values, Context context) 
			throws IOException, InterruptedException {
		
		int sum = 0;

		for (IntWritable value : values) {
			sum += value.get();
		}
		if (sum>=threshold) {
			context.write(key, new IntWritable(sum));
			try (PrintWriter o = new PrintWriter(new BufferedWriter(new FileWriter(manager.WHITELIST_PATH, true)))) {
			    o.println(key.toString()+","+sum);
			}catch (IOException e) {
			    System.out.println(e.getMessage());
			}
			
		}
	}

}
