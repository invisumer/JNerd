package it.uniroma3.nerAssociator.util;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Reader {
	private Map<String,Integer> whiteList;
	private static Reader instance;
	private NerAssociatorManager manager;
	
	private Reader() {
		this.manager = NerAssociatorManager.getInstance();
		this.whiteList = setup();
	}
	
	private Map<String,Integer> setup() {
		Map<String,Integer> list = new HashMap<String,Integer>();
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(manager.WHITELIST_PATH));

			String line = br.readLine();
			
	        while (line != null) {
	        	String[] lineSPlitted = line.split(",");
	        	int occurrence = Integer.parseInt(lineSPlitted[1]);
	        	list.put(lineSPlitted[0], occurrence);
	            line = br.readLine();
	        }
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
	        try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		return list;
	}
	
	public static Reader getInstance()	{
		if (instance==null) 
			return new Reader();
		return instance;
	}
	
	public Map<String,Integer> getWhiteList() {
		return this.whiteList;
	}
	
}
