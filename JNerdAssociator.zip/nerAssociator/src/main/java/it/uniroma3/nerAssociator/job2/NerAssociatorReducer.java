package it.uniroma3.nerAssociator.job2;

import it.uniroma3.nerAssociator.util.NerAssociatorManager;
import it.uniroma3.nerAssociator.util.Reader;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class NerAssociatorReducer extends Reducer<Text, IntWritable, Text, Text> {
	private NerAssociatorManager manager = NerAssociatorManager.getInstance();
	private TreeMap<String,List<String>> freq2pairs = new TreeMap<String,List<String>>();
	private Map<String,Integer> entities;
	private static int outputLimit;
	private static int percentageThreshold;
	private int denominator;
	private Text frequency = new Text();
	
	@Override
	protected void setup(Reducer<Text, IntWritable, Text, Text>.Context context)
			throws IOException, InterruptedException {
		Configuration conf = context.getConfiguration();
		outputLimit = Integer.parseInt(conf.get("outputLimit"));
		percentageThreshold = manager.PERCENTAGE_THRESHOLD;
		entities = Reader.getInstance().getWhiteList();
	}

	public void reduce(Text key, Iterable<IntWritable> values, Context context) 
			throws IOException, InterruptedException {
		String[] splitKey = key.toString().split(",");
		
		denominator = entities.get(splitKey[0]);
		int numerator = 0;
		for (IntWritable value : values) {
			numerator += value.get();
		}
		int perc = (int) Math.round( ((double) numerator / denominator) * 100);
		if (numerator>denominator)
			numerator=denominator;
		if (perc>percentageThreshold) {
			String numeratorString = normalizeValue(String.valueOf(numerator));
			String denominatorString = normalizeValue(String.valueOf(denominator));
			String percString = normalizePerc(String.valueOf(perc));
			String percentage = ( percString + "% (" + numeratorString + "/" + denominatorString + ")" );
			if (freq2pairs.containsKey(percentage)) {
				freq2pairs.get(percentage).add(key.toString());
			} else {
				List<String> pair = new ArrayList<String>();
				pair.add(key.toString());
				freq2pairs.put(percentage, pair);
			}
			if (freq2pairs.size() > outputLimit) {
				freq2pairs.remove(freq2pairs.firstKey());
			}
		}
		
	}
	
	private String normalizePerc(String perc) {
		if (perc.length() == 1)
			return "00"+perc;
		else if (perc.length() == 2)
			return "0"+perc;
		return perc;
	}
	
	private String normalizeValue(String value) {
		int difference = manager.ORDER_OF_SIZE-value.length();
		while (difference>0) {
			value = "0"+value;
			difference--;
		}
		return value;
	}
	
	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		int i =0;
		while (i<outputLimit && !freq2pairs.isEmpty()) {
			String key = freq2pairs.lastKey();
			frequency.set(String.valueOf(key));
			for (String pair : freq2pairs.get(key)) {
				if (i<outputLimit) {
					context.write(new Text(pair), frequency);
					i++;
				}
			}
			freq2pairs.remove(key);
		}
	}
}
