package it.uniroma3.nerAssociator;

import it.uniroma3.nerAssociator.job1.EntityCounterCombiner;
import it.uniroma3.nerAssociator.job1.EntityCounterMapper;
import it.uniroma3.nerAssociator.job1.EntityCounterReducer;
import it.uniroma3.nerAssociator.job2.NerAssociatorCombiner;
import it.uniroma3.nerAssociator.job2.NerAssociatorMapper;
import it.uniroma3.nerAssociator.job2.NerAssociatorReducer;
import it.uniroma3.nerAssociator.util.NerAssociatorManager;

import java.io.File;
import java.util.logging.Logger;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class NerAssociator extends Configured implements Tool {
	private NerAssociatorManager manager = NerAssociatorManager.getInstance();
	
	private static final Logger logger = Logger.getLogger(NerAssociator.class.getName());
    
    public int run(String[] args) throws Exception {
		
    	int job1ReduceTasks = manager.JOB1_REDUCERS;
    	int job2ReduceTasks = manager.JOB2_REDUCERS;
    	String inputPath = manager.INPUT_PATH;
    	String tempOutputPath = manager.OUTPUT_PATH+"-temp";
    	String outputPath = manager.OUTPUT_PATH;
    	String job2OutputLimit = manager.JOB2_OUTPUTLIMIT;
    	File f = new File(manager.WHITELIST_PATH);
    	f.delete();
    	
    	logger.info("Cleaning up temporary folder: " + outputPath);
		FileSystem fs = FileSystem.get(new Configuration());
		fs.delete(new Path(outputPath), true);
		
 		Job job1 = new Job(getConf());
 		job1.setJobName(NerAssociator.class.getSimpleName());
 		job1.setJarByClass(NerAssociator.class);
 		job1.setNumReduceTasks(job1ReduceTasks);
 		
 		FileInputFormat.addInputPath(job1, new Path(inputPath));
 		FileOutputFormat.setOutputPath(job1, new Path(tempOutputPath));
 		
 		job1.setMapperClass(EntityCounterMapper.class);
 		job1.setCombinerClass(EntityCounterCombiner.class);
 		job1.setReducerClass(EntityCounterReducer.class);

 		job1.setMapOutputKeyClass(Text.class);
 		job1.setMapOutputValueClass(IntWritable.class);
 		job1.setOutputKeyClass(Text.class);
 		job1.setOutputValueClass(IntWritable.class);
 		
 		long job0StartTime = System.currentTimeMillis();
 		job1.waitForCompletion(true);
 		double job0Time = (System.currentTimeMillis() - job0StartTime) / 1000.0;
 		logger.info("Job '" + job1.getJobName() 
 				+ "' Finished in " + job0Time + " seconds");
        
        // MAIN JOB
        
        Configuration conf = getConf();
        conf.set("outputLimit", job2OutputLimit);
        
        Job job2 = new Job(conf);
		job2.setJobName(NerAssociator.class.getSimpleName());
		job2.setJarByClass(NerAssociator.class);
		job2.setNumReduceTasks(job2ReduceTasks);
		
		FileInputFormat.addInputPath(job2, new Path(inputPath));
		FileOutputFormat.setOutputPath(job2, new Path(outputPath));
		
		job2.setMapperClass(NerAssociatorMapper.class);
		job2.setCombinerClass(NerAssociatorCombiner.class);
		job2.setReducerClass(NerAssociatorReducer.class);
		
		job2.setMapOutputKeyClass(Text.class);
		job2.setMapOutputValueClass(IntWritable.class);
		job2.setOutputKeyClass(Text.class);
		job2.setOutputValueClass(Text.class);
		
		long mainStartTime = System.currentTimeMillis();
		job2.waitForCompletion(true);
		double mainTime = (System.currentTimeMillis() - mainStartTime) / 1000.0;
		logger.info("Job '" + job2.getJobName() 
				+ "' Finished in " + mainTime + " seconds");
		fs.delete(new Path(tempOutputPath), true);	

		return 0;
    }
    
    public static void main(String[] args) throws Exception {
		int exitCode = ToolRunner.run(new NerAssociator(), args);
		System.exit(exitCode);
	}
}
