package it.uniroma3.nerAssociator.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class NerAssociatorManager {
	private static NerAssociatorManager instance;
	private static final String propertyPath = "META-INF/config/nerAssociator.properties";
	
	public String INPUT_PATH, OUTPUT_PATH, WHITELIST_PATH,
				JOB2_OUTPUTLIMIT;
	public int JOB1_REDUCERS, JOB1_THRESHOLD,
				JOB2_REDUCERS, ORDER_OF_SIZE, PERCENTAGE_THRESHOLD;
	
	private NerAssociatorManager() {
		try {
			
			Properties prop = new Properties();
			prop.load(this.getClass().getClassLoader().getResourceAsStream(propertyPath));
			
			INPUT_PATH = prop.getProperty("path.input");
			OUTPUT_PATH = prop.getProperty("path.output");
			WHITELIST_PATH = prop.getProperty("path.whitelist");
			
			JOB1_REDUCERS = Integer.parseInt(prop.getProperty("job1.numReducer"));
			JOB1_THRESHOLD = Integer.parseInt(prop.getProperty("job1.threshold"));
			
			JOB2_REDUCERS = Integer.parseInt(prop.getProperty("job2.numReducer"));
			JOB2_OUTPUTLIMIT = prop.getProperty("job2.outputLimit");
			ORDER_OF_SIZE = Integer.parseInt(prop.getProperty("job2.orderOfSize"));
			PERCENTAGE_THRESHOLD = Integer.parseInt(prop.getProperty("job2.percentageThreshold"));
		
		} catch (FileNotFoundException e) {
			System.out.println("Properties file could not be found: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("Properties file could not be loaded: " + e.getMessage());
		}
	}
	
	public static synchronized NerAssociatorManager getInstance() {
		if (instance==null) 
			instance = new NerAssociatorManager();
		return instance;
	}
}
