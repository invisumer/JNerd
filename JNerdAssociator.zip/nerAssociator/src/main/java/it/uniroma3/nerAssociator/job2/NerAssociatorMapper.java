package it.uniroma3.nerAssociator.job2;

import it.uniroma3.nerAssociator.util.Reader;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class NerAssociatorMapper  extends Mapper<Object, Text, Text, IntWritable> {
    private static final String inputFS = ",";
    private static final IntWritable one = new IntWritable(1);
    private Text pair = new Text();
    private Reader reader = Reader.getInstance();

    public void map(Object key, Text value, Context context)
            throws IOException, InterruptedException {
        Map<String,Integer> whiteList = reader.getWhiteList();
        String line = value.toString();
        StringTokenizer tokenizer = new StringTokenizer(line, inputFS);

        List<String> tokens = new ArrayList<String>();
        while (tokenizer.hasMoreTokens()) {
            String token = tokenizer.nextToken();
            if (whiteList.containsKey(token))
                tokens.add(token);
        }

        for (int i=0; i<tokens.size(); i++) {
            for (int j=0; j<tokens.size(); j++) {
                if (i != j) {
                    pair.set(tokens.get(i) + "," + tokens.get(j));
                    context.write(pair, one);
                }
            }
        }
    }
}
